import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class AppleCollector extends PApplet {

public void setup() 
{
  
  basket_image = loadImage("basket.png");
  apple_image = loadImage("Apple-icon.png");
  taco_image = loadImage("taco.png");
  face_image = loadImage("cartoonface.png");
  apples = new ArrayList<Fruit>();
  taco = new ArrayList<Fruit>();
  face = new ArrayList<Fruit>(); 
}
public void draw() 
{
    facespawn();
    tacospawn();
    if(state == 0){
       if (light)
           Light();
       if (!light)
           Menu();
  }
  if(state == 1) {
    if (!light)
       setting();
    else if (light)
       lsetting();
  } 
  if(state == 2){
       if (light)
           Lgamedraw();
       if(!light)
         gameDraw();
  }
  if(state == 3) {
     if (!light)
       lend();
     if (light)
       end();
  }
  
}

public boolean checkCollision(int bLeft, int bRight, int aX, int aY)
{      //Has to be touching the apple and is in the middle of the basket
    if(aY > 499 && aX < bRight && aX > bLeft)
      return true;
    return false;
}

public boolean fallen(int aY)
{
  if(aY > 511)
    return true;
   return false;
}
class Basket 
{
  int x = 0;
  int y = 500;
  
  public void display(int mX)
  {
    x = mX;
    image(basket_image, x - 50, y, 100, 100);
  }
}
public void lend(){
  background(0, 255, 255);
     fill(255);
     rect(x,y,w,h);
     rect(xx,yx,wx,hx);
     fill(0);
     textSize(25);
     text("Game over your score is " + score, 150, 180);
     textSize(14);
     text("To restart press this!", 230, 246);
     textSize(24);
     text("End Game!", 240, 346);
    }
public void end(){
  background(0);
  fill(255);
  rect(x,y,w,h);
  rect(xx,yx,wx,hx);
  fill(255);
  textSize(25);
  text("Game over your score is " + score, 150, 180);
  textSize(14);
  fill(0);
  text("To restart press this!", 230, 246);
  textSize(24);
  text("End Game!", 240, 346);
}
public void facespawn(){
  if(facecall){
  if (score == 10){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 20){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 30){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 40){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 50){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 60){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 70){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 80){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 90){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 100){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 110){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 120){
    face.add(new Fruit());
    facecall = false;
  } else if (score == 130){
    face.add(new Fruit());
    facecall = false;
  }
 }
}
class Fruit
{
  int x = (int)random(width);
  int y = 0;
  
  public void fall()
  {
    image(apple_image, x, y, 50, 50);
    y += 10;
  }
  public void ffall()
  {
    image(face_image, x, y, 50, 50);
    y += 10;
  }
  public void tacofall()
  {
    image(taco_image, x, y, 50, 50);
    y += 10;
  }
}
public void gameDraw(){
  background(0, 255, 255);
  currentTime = PApplet.parseInt(millis() / 1000);
  basket.display(mouseX);
  if(currentTime > prevTime) 
    apples.add(new Fruit());
  for(int i = 0; i < apples.size(); i++)
  {
    apples.get(i).fall();
    if(checkCollision(basket.x, basket.x + 100, apples.get(i).x + 50, apples.get(i).y))
    {
      score++;
      streak++;
      tacocall = true;
      facecall = true;
      apples.remove(i);
    }else if(fallen(apples.get(i).y))
    {
    life--;
    streak = 0;
    apples.remove(i);
    }  
  }
  for(int i = 0; i < taco.size(); i++)
  {
    taco.get(i).tacofall();
    if(checkCollision(basket.x, basket.x + 100, taco.get(i).x + 50, taco.get(i).y))
    {
      life++;
      streak++;
      tacocall = true;
      facecall = true;
      taco.remove(i);
    }else if(fallen(taco.get(i).y))
    {
    score--;
    streak = 0;
    taco.remove(i);
    }  
  }
  for(int i = 0; i < face.size(); i++)
  {
    face.get(i).ffall();
    if(checkCollision(basket.x, basket.x + 100, face.get(i).x + 50, face.get(i).y))
    {
      score++;
      streak++;
      tacocall = true;
      facecall = true;
      face.remove(i);
    }else if(fallen(face.get(i).y))
    {
    life--;
    streak = 0;
    face.remove(i);
    }  
  }
  fill(0);
  textSize(16);
  text("Your Score is: " + score + "!", width -150, 30);
  text("Life total: " + life + "!", width -150, 50);
  text("Your Streak: " + streak + "!", width -150, 70);
  prevTime = currentTime;
  delay(50);
  if(life == 0){
    state++;
    apples.remove(0);
    }
  if((keyPressed == true) && (key == 'j'))
    life++;
  }
  
public void Lgamedraw(){
  background(0);
  currentTime = PApplet.parseInt(millis() / 1000);
  basket.display(mouseX);
  
  if(currentTime > prevTime) 
    apples.add(new Fruit());
  for(int i = 0; i < apples.size(); i++)
  {
    apples.get(i).fall();
    if(checkCollision(basket.x, basket.x + 100, apples.get(i).x + 50, apples.get(i).y))
    {
      score++;
      streak++;
      tacocall = true;
      facecall = true;
      apples.remove(i);
    }else if(fallen(apples.get(i).y))
    {
    life--;
    streak = 0;
    apples.remove(i);
    }  
  }
  for(int i = 0; i < taco.size(); i++)
  {
    taco.get(i).tacofall();
    if(checkCollision(basket.x, basket.x + 100, taco.get(i).x + 50, taco.get(i).y))
    {
      life++;
      streak++;
      tacocall = true;
      facecall = true;
      taco.remove(i);
    }else if(fallen(taco.get(i).y))
    {
    score--;
    streak = 0;
    taco.remove(i);
    }  
  }
    for(int i = 0; i < face.size(); i++)
  {
    face.get(i).ffall();
    if(checkCollision(basket.x, basket.x + 100, face.get(i).x + 50, face.get(i).y))
    {
      score++;
      life++;
      streak++;
      tacocall = true;
      facecall = true;
      face.remove(i);
    }else if(fallen(face.get(i).y))
    {
    streak = 0;
    face.remove(i);
    }  
  }
  fill(255);
  textSize(16);
  text("Your Score is: " + score + "!", width -150, 30);
  text("Life total: " + life + "!", width -150, 50);
  text("Your Streak: " + streak + "!", width -150, 70);
  prevTime = currentTime;
  delay(50);
  if(life == 0){
    state++;
    apples.remove(0);
    }
  if((keyPressed == true) && (key == 'j'))
    life++;
  }
public void Menu() 
{
  background(0, 255, 255);
  textSize(16);
  fill(255);
  rect(x,y,w,h);
  rect(xs,ys,ws,hs);
  rect(xx,yx,wx,hx);
  fill(0);
  textSize(40);
  text("Apple Collector!", 160, 60);
  textSize(26);
  text("THE GAME!", 230, 100);
  text("Settings", 250, 245);
  textSize(18);
  text("Start the Game", 240, 156);
  textSize(24);
  text("End Game!", 240, 346);
}

public void Light() {
  background(0);
  textSize(16);
  fill(255);
  rect(x,y,w,h);
  rect(xs,ys,ws,hs);
  rect(xx,yx,wx,hx);
  fill(255);
  textSize(40);
  text("Apple Collector!", 160, 60);
  textSize(26);
  text("THE GAME!", 230, 100);
  fill(0);
  text("Settings", 250, 245);
  textSize(18);
  text("Start the Game", 240, 156);
  textSize(24);
  text("End Game!", 240, 346);
}
public void mouseReleased() {
  if(state ==0){
     if(mouseX>xs && mouseX <xs+ws && mouseY>ys && mouseY <ys+hs){
        state++;
        state++;
    }
    if(mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h)
        state++;
    if(mouseX>xx && mouseX <xx+wx && mouseY>yx && mouseY <yx+hx)
        exit();  
  } else if (state ==1){
    if(mouseX>x1 && mouseX <x1+w1 && mouseY>y1 && mouseY <y1+h1)
        state--;
    if(mouseX>xw && mouseX <xw+ww && mouseY>yw && mouseY <yw+hw)
        light = true;
    if(mouseX>xb && mouseX <xb+wb && mouseY>yb && mouseY <yb+hb)
        light = false;   
  } else if (state == 3) {
    if(mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h){
          state--;
          prevTime = 0;
          currentTime = 0;
          score = 0;
          life = 3;
          streak = 0;
          tacocall = true;
        }
   if(mouseX>xx && mouseX <xx+wx && mouseY>yx && mouseY <yx+hx)
       exit(); 
    
    
    
  }
}
public void setting() {
  background(0, 255, 255);
  textSize(16);
  fill(255);
  rect(xb,yb,wb,hb);
  rect(xw,yw,ww,hw);
  rect(x1,y1,w1,h1);
  fill(0);
  textSize(40);
  text("Settings", 230, 60);
  textSize(20);
  text("Back to Menu", 235, 325);
  textSize(16);
  text("Dark Mode", 180, 156);
  text("Light Mode", 330, 156);  
}
public void lsetting() {
  background(0);
  textSize(16);
  fill(255);
  rect(xb,yb,wb,hb);
  rect(xw,yw,ww,hw);
  rect(x1,y1,w1,h1);
  fill(255);
  textSize(40);
  text("Settings", 230, 60);
  textSize(20);
  fill(0);
  text("Back to Menu", 235, 325);
  textSize(16);
  text("Dark Mode", 180, 156);
  text("Light Mode", 330, 156);
}
public void tacospawn(){
    if(tacocall){
   if(streak == 5) {
     taco.add(new Fruit());
     tacocall = false;
  } else if(streak == 10) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 15) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 20) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 25) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 30) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 35) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 40) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 45) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 50) {
     taco.add(new Fruit());
     tacocall = false; 
  }else if(streak == 55) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 60) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 65) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 70) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 75) {
     taco.add(new Fruit());
     tacocall = false; 
  } else if(streak == 80) {
     taco.add(new Fruit());
     tacocall = false; 
  }
  }
}
PImage apple_image;
PImage basket_image;
PImage taco_image;
PImage face_image;
boolean tacocall = true;
boolean light = false;
boolean facecall = true;
int state;
int x = 225;
int y = 200;
int w = 150;
int h = 80;
int xs = 225;
int ys = 110;
int ws = 150;
int hs = 80;
int x1 = 225;
int y1 = 280;
int w1 = 150;
int h1 = 80;
int xw = 170;
int yw = 110;
int ww = 100;
int hw = 80;
int xb = 320;
int yb = 110;
int wb = 100;
int hb = 80;
int xx = 225;
int yx = 300;
int wx = 150;
int hx = 80;


Basket basket = new Basket();
ArrayList<Fruit> apples;
ArrayList<Fruit> taco;
ArrayList<Fruit> face;
int prevTime = 0;
int currentTime = 0;
int score = 0;
int life = 3;
int streak = 0;
  public void settings() {  size(600, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "AppleCollector" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
